module com.example.deepostbank {
    requires javafx.controls;
    requires javafx.fxml;
    requires de.jensd.fx.glyphs.fontawesome;



    requires com.dlsc.formsfx;

    opens com.example.deepositbank to javafx.fxml;
    exports com.example.deepositbank;
    exports com.example.deepositbank.Controllers;
    exports com.example.deepositbank.Controllers.AccountManager;
    exports com.example.deepositbank.Controllers.Customer;
    exports com.example.deepositbank.Models;
    exports com.example.deepositbank.Views;

}