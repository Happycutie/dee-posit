package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.*;
import com.example.deepositbank.Views.BankAccountType;
import com.example.deepositbank.Views.CustomerType;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddNewCustomerController<event> implements Initializable {

    public ChoiceBox<CustomerType> customer_selector;
    public TextField fName_fld;
    public TextField lName_fld;
    public TextField address_fld;
    public PasswordField password_fld;
    public ChoiceBox<BankAccountType> bank_acc_selector;
    public CheckBox aNumber_box;
    public Label aNumber_lbl;

    public Button add_new_customer_btn;

    public CheckBox id_box;


    //add Card//
    public TextField acc_n_fld;
    public TextField card_name_fld;
    public TextField card_num_fld;
    public TextField cvc_fld;
    public TextField credit_fld;
    public DatePicker date_created;
    public DatePicker issue_date;
    public DatePicker expired_date;
    public TextField confirm_pin_fld;
    public TextField pin_fld;
    public TextField max_limit_fld;
    public TextField card_type_fld;
    public Button Confirm_card_btn;

    public TextField acc_bala_fld;

    public CheckBox sCode_box;
    public Label sCode_lbl;

    public Label error_lbl;

    private String accountNumber;
    private String sortCode;

    private boolean createRewardAccountFlag = false;
    private boolean createBasicAccountFlag = false;
    private boolean createIsaAccountFlag = false;



    @FXML
    private Label msg1;

    @FXML
    private Label msg2;


    @FXML
    void addCard(ActionEvent event) {
        String acno, cardno, cardname, cvc, issue, expire, credit, cardtype, maxlimit, pin, confpin;
        acno = acc_n_fld.getText();
        cardno = card_num_fld.getText();
        cardname = card_name_fld.getText();
        cvc = cvc_fld.getText();
        credit = credit_fld.getText();
        issue = issue_date.getValue().toString(); // Assuming issue_date is a DatePicker
        expire = expired_date.getValue().toString(); // Assuming expired_date is a DatePicker
        cardtype = card_type_fld.getText();
        maxlimit = max_limit_fld.getText();
        pin = pin_fld.getText();
        confpin = confirm_pin_fld.getText();

        if (pin.equals(confpin)) {
            // Simulating the card info insertion into a database
            // Replace this simulation with your actual database handling code
            simulateCardInsertion(acno, cardno, cardname, cardtype, pin, cvc, issue, expire, credit, maxlimit);
        } else {
            msg2.setText("Pin doesn't match. Unsuccessful");
        }
    }

    private void simulateCardInsertion(String acno, String cardno, String cardname, String cardtype, String pin,
                                       String cvc, String issue, String expire, String credit, String maxlimit) {
        // Simulating the card info insertion (Print to console for simulation)
        System.out.println("Simulating card info insertion:");
        System.out.println("Account Number: " + acno);
        System.out.println("Card Number: " + cardno);
        System.out.println("Card Name: " + cardname);
        System.out.println("Card Type: " + cardtype);
        System.out.println("PIN: " + pin);
        System.out.println("CVC: " + cvc);
        System.out.println("Issue Date: " + issue);
        System.out.println("Expiration Date: " + expire);
        System.out.println("Credit: " + credit);
        System.out.println("Max Limit: " + maxlimit);

        msg2.setText("Card successfully Added."); // Update UI or message
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        add_new_customer_btn.setOnAction(event -> createCustomer());
        sCode_box.selectedProperty().addListener((observableValue, oldVal, newVal) -> {
            if (newVal) {
                sortCode = createSortCode();
                onCreateSortCode();
            }
        });
        aNumber_box.selectedProperty().addListener((observableValue, oldVal, newVal) -> {
            if (newVal) {
                accountNumber = createAccountNumber();
                onCreateAccountNumber();
            }
        });

        customer_selector.setItems(FXCollections.observableArrayList(CustomerType.INDIVIDUAL, CustomerType.BUSINESS, CustomerType.CHARITY));
        bank_acc_selector.setItems(FXCollections.observableArrayList(BankAccountType.REWARD_ACCOUNT, BankAccountType.BASIC_ACCOUNT, BankAccountType.ISA_ACCOUNT));
        bank_acc_selector.getSelectionModel().selectedItemProperty().addListener((observableValue, oldVal, newVal) -> {
            switch (newVal) {
                case REWARD_ACCOUNT:
                    handleRewardAccountSelection();
                    break;
                case BASIC_ACCOUNT:
                    handleBasicAccountSelection();
                    break;
                case ISA_ACCOUNT:
                    handleIsaAccountSelection();
                    break;
                default:
                    // Handle default behavior or error for unsupported account type
                    break;
            }
        });
    }

    private void handleRewardAccountSelection() {
        RewardAccount rewardAccount = new RewardAccount(accountNumber, "", 0);
        rewardAccount.processCardTransaction(0); // Pass appropriate parameters
        rewardAccount.applyInterest();
        int interestRate = rewardAccount.getInterestRate();
        rewardAccount.setInterestRate(0); // Set an appropriate interest rate
    }

    private void handleBasicAccountSelection() {
        BasicAccount basicAccount = new BasicAccount(accountNumber, "", 0);
        basicAccount.processCardTransaction(0); // Pass appropriate parameters
    }

    private void handleIsaAccountSelection() {
        IsaAccount isaAccount = new IsaAccount(accountNumber, "", 0);
        isaAccount.applyInterest();
        int interestRate = isaAccount.getInterestRate();
        isaAccount.setInterestRate(0); // Set an appropriate interest rate
    }

    // Implement or remove undefined methods
    private String createSortCode() {
        // Implement logic to generate a sort code
        return "";
    }

    private String generateAccountNumber() {
        // Implement logic to generate an account number
        return "";
    }

    private void onCreateSortCode() {
        // Implement logic when creating sort code
    }
    private String createAccountNumber() {
        // Logic to create account number
        return "";
    }

    private void onCreateAccountNumber() {
        if (fName_fld.getText().isEmpty() && !lName_fld.getText().isEmpty()) {
            aNumber_lbl.setText(accountNumber);
        }
    }

    private void createCustomer() {
        BankAccountType selectedAccountType = bank_acc_selector.getValue();

        if (selectedAccountType == BankAccountType.BASIC_ACCOUNT) {
            createBasicAccountFlag = true; // Implement flag logic...
        } else if (selectedAccountType == BankAccountType.REWARD_ACCOUNT) {
            createRewardAccountFlag = true; // Implement flag logic...
        } else if (selectedAccountType == BankAccountType.ISA_ACCOUNT) {
            createIsaAccountFlag = true; // Implement flag logic...
        }

        String fName = fName_fld.getText();
        String lName = lName_fld.getText();
        String password = password_fld.getText();
        String sortcode = sCode_lbl.getText();

        // Simulate or handle customer data without a database
        Customer customer = new Customer(fName, lName, sortcode, password, LocalDate.now());

        error_lbl.setStyle("-fx-text-fill: blue; -fx-font-size: 1.3em; -fx-font-weight: bold");
        error_lbl.setText("Customer Created Successfully!");
        emptyFields();
    }


    private void createAccount(Account accountType) {
        double balance = 0; // Set balance based on TextField input
        String accountNumber = generateAccountNumber(); // Generate an account number

        // Simulate creating account without a database
        // You might manage accounts using data structures or simulate account creation
    }


    private void emptyFields() {
        fName_fld.setText("");
        lName_fld.setText("");
        password_fld.setText("");
        aNumber_box.setSelected(false);
        aNumber_lbl.setText("");
        sCode_box.setSelected(false);
        sCode_lbl.setText("");

        customer_selector.getSelectionModel().clearSelection();
        bank_acc_selector.getSelectionModel().clearSelection();
    }
}

