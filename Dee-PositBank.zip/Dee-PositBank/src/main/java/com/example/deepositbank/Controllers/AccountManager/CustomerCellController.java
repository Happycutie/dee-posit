package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Customer;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomerCellController implements Initializable {

    public Label fName_lbl;
    public Label lName_lbl;
    public Label Sender_acc_lbl;
    public Label receiver_acc_lbl;
    public Label date_lbl;
    public Button delete_btn;
    public Button edit_btn;

    private final Customer customer;

    public CustomerCellController(Customer customer) {
        this.customer = customer;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        fName_lbl.textProperty().bind(customer.firstNameProperty());
        lName_lbl.textProperty().bind(customer.lastNameProperty());
        Sender_acc_lbl.textProperty().bind(customer.aNumberProperty());
        receiver_acc_lbl.textProperty().bind(customer.receiverNumberProperty()); // Corrected binding if needed
        date_lbl.textProperty().bind(customer.dateProperty().asString());
        edit_btn.textProperty().bind(customer.editProperty().asString());
        delete_btn.textProperty().bind(customer.deleteProperty().asString());
    }
}
