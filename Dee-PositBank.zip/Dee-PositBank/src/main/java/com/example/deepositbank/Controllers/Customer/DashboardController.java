package com.example.deepositbank.Controllers.Customer;

import com.example.deepositbank.Models.Customer;
import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Views.TransactionCellFactory;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    public Text user_name;
    public Label login_date;
    public Label income_lbl;
    public Label expense_lbl;
    public ListView transaction_listview;
    public TextField bank_acc_fld;
    public TextField amount_fld;
    public TextArea message_fld;
    public Button Send_money_btn;
    public TextField sort_code_fld;
    public Label card_number;

    public Text account_Type_Label_fld;
    public Label balance;
    public Label acc_num;
    public Label visa_amount;

    private Customer customer; // Placeholder for your Customer class

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customer = Model.getInstance().getCustomer(); // Get customer data

        bindData();
        initLatestTransactionsList();
        transaction_listview.setItems(Model.getInstance().getLatestTransactions());
        transaction_listview.setCellFactory(e -> new TransactionCellFactory());
        Send_money_btn.setOnAction(event -> onSendMoney());
        accountSummary();
    }

    private void bindData() {
        user_name.setText("Hi, " + customer.getFirstName());
        login_date.setText("Today, " + LocalDate.now());

        // Assuming you have different types of accounts in your Customer class
        Account rewardAccount = customer.getRewardAccount();
        Account basicAccount = customer.getBasicAccount();
        Account isaAccount = customer.getIsaAccount();

        // Bind account type label based on different accounts
        account_Type_Label_fld.setText(rewardAccount.getType());

        // Bind balance and account number based on different accounts
        balance.textProperty().bind(rewardAccount.balanceProperty().asString());
        acc_num.textProperty().bind(rewardAccount.accountNumberProperty());
        visa_amount.textProperty().bind(rewardAccount.visaProperty().asString());
        // Repeat similar bindings for basicAccount and isaAccount

        // Simulate the creation of an account (You need to implement your actual logic here)
        // Example: customer.createRewardAccount();
        // Example: customer.createBasicAccount();
        // Example: customer.createIsaAccount();

        // Simulate the creation of a Visa card (You need to implement your actual logic here)
        // Example: customer.createVisaCard();
    }

    private void initLatestTransactionsList() {
        // Simulate initializing the latest transactions list (You need to implement your actual logic here)
    }

    private void onSendMoney() {
        // Simulate the logic for sending money (You need to implement your actual logic here)
        String receiver = bank_acc_fld.getText();
        double amount = Double.parseDouble(amount_fld.getText());
        String message = message_fld.getText();

        // Example: customer.sendMoney(receiver, amount, message);

        // Clear the fields after sending money
        bank_acc_fld.clear();
        amount_fld.clear();
        message_fld.clear();
    }

    private void accountSummary() {
        // Simulate calculating income and expenses (You need to implement your actual logic here)
        double income = 0;
        double expenses = 0;

        // Example: income = customer.calculateIncome();
        // Example: expenses = customer.calculateExpenses();

        income_lbl.setText("+ $" + income);
        expense_lbl.setText("- $" + expenses);
    }
}
