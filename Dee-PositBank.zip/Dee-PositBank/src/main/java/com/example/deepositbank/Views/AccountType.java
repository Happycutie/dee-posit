package com.example.deepositbank.Views;

public enum AccountType {
    ACCOUNT_MANAGER,

    CUSTOMER,



}
