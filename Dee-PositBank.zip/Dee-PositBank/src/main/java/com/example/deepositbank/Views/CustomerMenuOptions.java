package com.example.deepositbank.Views;

public enum CustomerMenuOptions {

    DASHBOARD,

    TRANSACTIONS,

    REPORT, SETTINGS, ACCOUNTS
}
