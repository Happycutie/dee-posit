package com.example.deepositbank.Controllers.AccountManager;

import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomersController implements Initializable {


    public ListView customers_listview;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
