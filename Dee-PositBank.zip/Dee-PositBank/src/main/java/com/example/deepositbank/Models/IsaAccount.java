package com.example.deepositbank.Models;

public class IsaAccount extends Account implements SavingsAccount {
    public IsaAccount(String accountNumber, String sortCode, int balance) {
        super(accountNumber, sortCode, balance);
    }

    @Override
    public void applyInterest() {
        // Logic for applying interest to an ISA account
    }

    @Override
    public int getInterestRate() {
        // Logic to get the interest rate of an ISA account
        return 0; // Replace with actual logic
    }

    @Override
    public void setInterestRate(int rate) {
        // Logic to set the interest rate of an ISA account
    }
}