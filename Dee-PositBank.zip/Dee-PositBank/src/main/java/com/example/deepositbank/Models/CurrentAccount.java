package com.example.deepositbank.Models;

public interface CurrentAccount {
    void processCardTransaction(int amount);
}
