package com.example.deepositbank.Models;

public interface SavingsAccount {
    void applyInterest();
    int getInterestRate();
    void setInterestRate(int rate);
}