package com.example.deepositbank.Models;


import com.example.deepositbank.Views.ViewFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDate;

public class Model {
    private static Model model;
    private final ViewFactory viewFactory;

    // Client Data Section
    private final Customer customer;
    private boolean customerLoginSuccessFlag;
    private final ObservableList<Transaction> latestTransactions;
    private final ObservableList<Transaction> allTransactions;

    // Admin Data Section
    private boolean accountManagerLoginSuccessFlag;
    private final ObservableList<Customer> customers;

    private Model() {
        this.viewFactory = new ViewFactory();
        // Client Data Section
        this.customerLoginSuccessFlag = false;
        this.customer = new Customer("", "", "", null, null);
        this.latestTransactions = FXCollections.observableArrayList();
        this.allTransactions = FXCollections.observableArrayList();
        // Admin Data Section
        this.accountManagerLoginSuccessFlag = false;
        this.customers = FXCollections.observableArrayList();
    }

    public static synchronized Model getInstance() {
        if (model == null) {
            model = new Model();
        }
        return model;
    }

    public ViewFactory getViewFactory() {
        return viewFactory;
    }

    /*
     * Client Method Section
     * */
    public boolean getCustomerLoginSuccessFlag() {
        return this.customerLoginSuccessFlag;
    }

    public void setCustomerLoginSuccessFlag(boolean flag) {
        this.customerLoginSuccessFlag = flag;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void evaluateClientCred(String aNumber, String sCode, String password) {
        // Simulated client data retrieval without the actual database interaction
        this.customer.firstNameProperty().set("John");
        this.customer.lastNameProperty().set("Doe");
        this.customer.aNumberProperty().set("123456");
        this.customer.dateProperty().set(LocalDate.now());

        // Simulate setting client's accounts without actual database retrieval
        RewardAccount rewardAccount = new RewardAccount(aNumber, "12345", 5000);
        BasicAccount basicAccount = new BasicAccount(aNumber, "54321", 10000);
        IsaAccount isaAccount = new IsaAccount(aNumber, "98765", 20000);

        this.customer.rewardAccountProperty().set(rewardAccount);
        this.customer.basicAccountProperty().set(basicAccount);
        this.customer.isaAccountProperty().set(isaAccount);

        this.customerLoginSuccessFlag = true;
    }

    // Simulated method to prepare transactions
    private void prepareTransactions(ObservableList<Transaction> transactions, int limit) {
        // Simulate preparing transactions without actual database interaction
        // ... (simulate adding transactions to the list)
    }

    public void setLatestTransactions() {
        prepareTransactions(this.latestTransactions, 4);
    }

    public ObservableList<Transaction> getLatestTransactions() {
        return latestTransactions;
    }

    public void setAllTransactions() {
        prepareTransactions(this.allTransactions, -1);
    }

    public ObservableList<Transaction> getAllTransactions() {
        return allTransactions;
    }

    /*
     * Admin Method Section
     * */

    public boolean getAccountManagerLoginSuccessFlag() {
        return this.accountManagerLoginSuccessFlag;
    }

    public void setAccountManagerLoginSuccessFlag(boolean adminLoginSuccessFlag) {
        this.accountManagerLoginSuccessFlag = adminLoginSuccessFlag;
    }

    public void evaluateAdminCred(String username, String password) {
        // Simulate admin data retrieval without actual database interaction
        this.accountManagerLoginSuccessFlag = true; // Set admin flag to true for simulation
    }

    public ObservableList<Customer> getCustomers() {
        return customers;
    }

    // Simulated method to set clients without database interaction
    public void setCustomers() {
        // ... (simulate setting clients without actual database retrieval)
    }

    // Simulated method to search client without actual database interaction
    public ObservableList<Customer> searchClient(String pAddress) {
        ObservableList<Customer> searchResults = FXCollections.observableArrayList();
        // ... (simulate searching client without actual database interaction)
        return searchResults;
    }

    /*
     * Utility Methods Section
     * */
    public CurrentAccount getCheckingAccount(String aNumber) {
        // Simulate getting checking account without actual database retrieval
        return null; // Replace with actual implementation
    }

    public SavingsAccount getSavingsAccount(String pAddress) {
        // Simulate getting savings account without actual database retrieval
        return null; // Replace with actual implementation
    }
}
