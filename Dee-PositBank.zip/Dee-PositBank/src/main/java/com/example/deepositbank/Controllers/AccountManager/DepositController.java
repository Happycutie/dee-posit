package com.example.deepositbank.Controllers.AccountManager;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class DepositController implements Initializable {

    public TextField aNumber_fld;
    public Button search_btn;
    public ListView result_listview;
    public TextField deposit_amount_fld;
    public TextField withdraw_amount_fld;
    public Button deposit_btn;
    public Button withdraw_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
