package com.example.deepositbank.Controllers.Customer;

import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

public class SettingsController {
    public PasswordField old_password_fld;
    public PasswordField new_password_fld;
    public PasswordField confirm_password_fld;
    public Button change_btn;
}
